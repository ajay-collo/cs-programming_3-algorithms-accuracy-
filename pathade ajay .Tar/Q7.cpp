#include <iostream>
#include <string>

using namespace std;

struct PrintJob {
    int jobId;
    string userName;
    int pages;
};

class CircularQueue {
private:
    int front, rear, capacity;
    PrintJob* arr;

public:
    CircularQueue(int size) {
        capacity = size;
        arr = new PrintJob[capacity];
        front = rear = -1;
    }

    bool isFull() {
        return (front == 0 && rear == capacity - 1) || (rear == (front - 1) % (capacity - 1));
    }

    bool isEmpty() {
        return front == -1;
    }

    void insertJob(int id, string name, int pages) {
        if (isFull()) {
            cout << "Printer Queue is FULL! Cannot add job." << endl;
            return;
        }
        if (front == -1) {
            front = rear = 0;
        } else if (rear == capacity - 1 && front != 0) {
            rear = 0;
        } else {
            rear++;
        }
        arr[rear] = {id, name, pages};
        cout << "Job " << id << " added successfully for " << name << "." << endl;
    }

    void processJob() {
        if (isEmpty()) {
            cout << "Printer Queue is EMPTY! No jobs to process." << endl;
            return;
        }
        PrintJob job = arr[front];
        cout << "Processing & Printing Job ID: " << job.jobId << " | User: " << job.userName << " | Pages: " << job.pages << endl;

        if (front == rear) {
            front = rear = -1;
        } else if (front == capacity - 1) {
            front = 0;
        } else {
            front++;
        }
    }

    void displayJobs() {
        if (isEmpty()) {
            cout << "No pending print jobs." << endl;
            return;
        }
        cout << "\n--- Current Pending Print Jobs ---" << endl;
        int i = front;
        while (true) {
            cout << "Job ID: " << arr[i].jobId << " | User: " << arr[i].userName << " | Pages: " << arr[i].pages << endl;
            if (i == rear) break;
            i = (i + 1) % capacity;
        }
        cout << "----------------------------------\n" << endl;
    }
};

int main() {
    CircularQueue printer(3);

    printer.insertJob(1, "Ajay", 5);
    printer.insertJob(2, "Rahul", 12);
    printer.insertJob(3, "Priya", 3);

    printer.displayJobs();

    printer.processJob();
    printer.insertJob(4, "Amit", 8);

    printer.displayJobs();

    return 0;
}
