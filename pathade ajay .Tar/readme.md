# C++ Data Structures & Algorithms Assignment

Hey there! This repository contains my C++ solutions for the data structures and algorithms assignment covering hospital queues, student record BSTs, browser navigation, social network graphs, employee records, expression trees, printer queues, prerequisite graphs, CPU schedulers, and max-heap tasks

1. `Q1-application.cpp` - Hospital Emergency Department Patient Queue (FIFO & Priority structure)
2. `Q2.cpp` - College Student Record Management using Binary Search Tree (BST)
3. `Q3.cpp` - Browser Navigation System using Two Stacks (Back & Forward)
4. `Q4.cpp` - Social Network Graph with BFS and DFS Traversals
5. `Q5.cpp` - Employee Record Management using Singly Linked List
6. `Q6.cpp` - Expression Tree Construction and Arithmetic Evaluation
7. `Q7.cpp` - Shared Printer Job Queue using Circular Queue
8. `Q8.cpp` - Course Prerequisite System using Directed Graph
9. `Q9.cpp` - Operating System CPU Process Scheduling Priority Queue
10. `Q10.cpp` - Task Urgency Management using Max-Heap

