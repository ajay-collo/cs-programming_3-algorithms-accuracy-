#include <iostream>
#include <string>

using namespace std;

struct Student {
    int rollNo;
    string name;
    string department;
};

struct Node {
    Student data;
    Node* left;
    Node* right;
    
    Node(int roll, string n, string dept) {
        data.rollNo = roll;
        data.name = n;
        data.department = dept;
        left = right = nullptr;
    }
};

class StudentBST {
private:
    Node* root;

    Node* insertRec(Node* node, Student student) {
        if (node == nullptr) return new Node(student.rollNo, student.name, student.department);
        if (student.rollNo < node->data.rollNo)
            node->left = insertRec(node->left, student);
        else if (student.rollNo > node->data.rollNo)
            node->right = insertRec(node->right, student);
        return node;
    }

    Node* searchRec(Node* node, int rollNo) {
        if (node == nullptr || node->data.rollNo == rollNo) return node;
        if (rollNo < node->data.rollNo) return searchRec(node->left, rollNo);
        return searchRec(node->right, rollNo);
    }

    void inorderRec(Node* node) {
        if (node != nullptr) {
            inorderRec(node->left);
            cout << "Roll No: " << node->data.rollNo << " | Name: " << node->data.name << " | Dept: " << node->data.department << endl;
            inorderRec(node->right);
        }
    }

    Node* findMinRec(Node* node) {
        while (node && node->left != nullptr) node = node->left;
        return node;
    }

    Node* findMaxRec(Node* node) {
        while (node && node->right != nullptr) node = node->right;
        return node;
    }

public:
    StudentBST() { root = nullptr; }

    void insert(int roll, string name, string dept) {
        root = insertRec(root, {roll, name, dept});
    }

    void search(int rollNo) {
        Node* res = searchRec(root, rollNo);
        if (res != nullptr)
            cout << "Found Student -> Roll No: " << res->data.rollNo << ", Name: " << res->data.name << ", Dept: " << res->data.department << endl;
        else
            cout << "Student with Roll No " << rollNo << " not found." << endl;
    }

    void inorder() {
        cout << "\n--- Student Records (Inorder Traversal) ---" << endl;
        inorderRec(root);
        cout << "-------------------------------------------\n" << endl;
    }

    void findMin() {
        Node* minNode = findMinRec(root);
        if (minNode)
            cout << "Minimum Roll Number -> Roll No: " << minNode->data.rollNo << " (" << minNode->data.name << ")" << endl;
        else
            cout << "Tree is empty." << endl;
    }

    void findMax() {
        Node* maxNode = findMaxRec(root);
        if (maxNode)
            cout << "Maximum Roll Number -> Roll No: " << maxNode->data.rollNo << " (" << maxNode->data.name << ")" << endl;
        else
            cout << "Tree is empty." << endl;
    }
};

int main() {
    StudentBST bst;

    bst.insert(105, "Ajay Pathade", "Computer Science");
    bst.insert(102, "Rahul Sharma", "Information Tech");
    bst.insert(110, "Priya Patil", "Data Science");
    bst.insert(101, "Amit Kulkarni", "Computer Science");
    bst.insert(108, "Sneha Deshmukh", "Electronics");
    bst.insert(103, "Vikas Jadhav", "Mechanical");
    bst.insert(112, "Neha Shinde", "AI & ML");
    bst.insert(107, "Karan More", "Civil");

    bst.inorder();

    cout << "Executing Search Test Cases:" << endl;
    bst.search(108);
    bst.search(999); 

    cout << "\nExecuting Min & Max Tests:" << endl;
    bst.findMin();
    bst.findMax();

    return 0;
}
