#include <iostream>
#include <stack>
#include <string>
#include <cctype>

using namespace std;

struct Node {
    string val;
    Node* left;
    Node* right;
    
    Node(string v) {
        val = v;
        left = right = nullptr;
    }
};

class ExpressionTree {
public:
    Node* constructTree(string postfix) {
        stack<Node*> st;
        for (char c : postfix) {
            if (isspace(c)) continue;
            if (isalnum(c)) {
                st.push(new Node(string(1, c)));
            } else {
                Node* t = new Node(string(1, c));
                t->right = st.top(); st.pop();
                t->left = st.top(); st.pop();
                st.push(t);
            }
        }
        return st.top();
    }

    void inorder(Node* root) {
        if (root) {
            inorder(root->left);
            cout << root->val << " ";
            inorder(root->right);
        }
    }

    void preorder(Node* root) {
        if (root) {
            cout << root->val << " ";
            preorder(root->left);
            preorder(root->right);
        }
    }

    void postorder(Node* root) {
        if (root) {
            postorder(root->left);
            postorder(root->right);
            cout << root->val << " ";
        }
    }

    int evaluate(Node* root) {
        if (!root) return 0;
        if (!root->left && !root->right) return stoi(root->val);

        int leftVal = evaluate(root->left);
        int rightVal = evaluate(root->right);

        if (root->val == "+") return leftVal + rightVal;
        if (root->val == "-") return leftVal - rightVal;
        if (root->val == "*") return leftVal * rightVal;
        if (root->val == "/") return leftVal / rightVal;

        return 0;
    }
};

int main() {
    ExpressionTree et;
    string postfix = "AB+CD-*"; 
    Node* root = et.constructTree(postfix);

    cout << "Inorder: "; et.inorder(root); cout << endl;
    cout << "Preorder: "; et.preorder(root); cout << endl;
    cout << "Postorder: "; et.postorder(root); cout << endl;

    string numPostfix = "84+10 6-*"; 
    Node* numRoot = et.constructTree("84+106-*");
    cout << "Evaluated Numeric Expression result for (8+4)*(10-6): " << et.evaluate(numRoot) << endl;

    return 0;
}
