#include <iostream>
#include <stack>
#include <string>

using namespace std;

class BrowserNavigation {
private:
    stack<string> backwardStack;
    stack<string> forwardStack;
    string currentPage;

public:
    BrowserNavigation(string homePage) {
        currentPage = homePage;
        cout << "Browser launched. Current Page: " << currentPage << endl;
    }

    void visit(string url) {
        backwardStack.push(currentPage);
        currentPage = url;
        while (!forwardStack.empty()) {
            forwardStack.pop();
        }
        cout << "Visited: " << currentPage << endl;
    }

    void goBack() {
        if (backwardStack.empty()) {
            cout << "No previous page to go back to." << endl;
            return;
        }
        forwardStack.push(currentPage);
        currentPage = backwardStack.top();
        backwardStack.pop();
        cout << "Going Back. Current Page: " << currentPage << endl;
    }

    void goForward() {
        if (forwardStack.empty()) {
            cout << "No forward page available." << endl;
            return;
        }
        backwardStack.push(currentPage);
        currentPage = forwardStack.top();
        forwardStack.pop();
        cout << "Going Forward. Current Page: " << currentPage << endl;
    }

    void displayCurrent() {
        cout << "Current Webpage Display: " << currentPage << endl;
    }
};

int main() {
    BrowserNavigation browser("Google");

    browser.visit("YouTube");
    browser.visit("Wikipedia");
    browser.visit("SPPU");

    browser.displayCurrent();

    browser.goBack();
    browser.goBack();

    browser.goForward();

    browser.visit("GitHub");
    browser.displayCurrent();

    return 0;
}
