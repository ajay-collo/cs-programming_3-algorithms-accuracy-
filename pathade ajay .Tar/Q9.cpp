#include <iostream>
#include <string>
#include <vector>
#include <queue>

using namespace std;

struct Process {
    int id;
    string name;
    int priority;
    int executionTime;

    bool operator<(const Process& other) const {
        return priority < other.priority;
    }
};

class CPUScheduler {
private:
    priority_queue<Process> pq;

public:
    void insertProcess(int id, string name, int priority, int time) {
        pq.push({id, name, priority, time});
        cout << "Process " << name << " (ID: " << id << ") inserted." << endl;
    }

    void deleteHighestPriority() {
        if (pq.empty()) {
            cout << "No processes in queue." << endl;
            return;
        }
        Process p = pq.top();
        pq.pop();
        cout << "Executing & Removing Highest Priority Process -> ID: " << p.id << ", Name: " << p.name << ", Priority: " << p.priority << endl;
    }

    void displayWaitingProcesses() {
        if (pq.empty()) {
            cout << "Waiting queue is empty." << endl;
            return;
        }
        priority_queue<Process> temp = pq;
        cout << "\n--- Waiting Processes (Priority Order) ---" << endl;
        while (!temp.empty()) {
            Process p = temp.top();
            temp.pop();
            cout << "ID: " << p.id << " | Name: " << p.name << " | Priority: " << p.priority << " | Time: " << p.executionTime << "s" << endl;
        }
        cout << "-------------------------------------------\n" << endl;
    }
};

int main() {
    CPUScheduler scheduler;

    scheduler.insertProcess(1, "TextEditor", 2, 10);
    scheduler.insertProcess(2, "KernelUpdate", 10, 5);
    scheduler.insertProcess(3, "BackgroundSync", 1, 15);

    scheduler.displayWaitingProcesses();

    scheduler.deleteHighestPriority();
    scheduler.displayWaitingProcesses();

    return 0;
}
