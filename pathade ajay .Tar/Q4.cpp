#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <queue>

using namespace std;

class SocialNetwork {
private:
    map<string, list<string>> adjList;

    void dfsHelper(string person, map<string, bool>& visited) {
        visited[person] = true;
        cout << person << " ";
        for (string friendName : adjList[person]) {
            if (!visited[friendName]) {
                dfsHelper(friendName, visited);
            }
        }
    }

public:
    void addPerson(string person) {
        if (adjList.find(person) == adjList.end()) {
            adjList[person] = list<string>();
        }
    }

    void addFriendship(string p1, string p2) {
        adjList[p1].push_back(p2);
        adjList[p2].push_back(p1);
    }

    void displayGraph() {
        cout << "\n--- Social Network Connections ---" << endl;
        for (auto pair : adjList) {
            cout << pair.first << " -> ";
            for (string f : pair.second) {
                cout << f << ", ";
            }
            cout << endl;
        }
        cout << "----------------------------------\n" << endl;
    }

    void bfs(string startPerson) {
        map<string, bool> visited;
        queue<string> q;

        q.push(startPerson);
        visited[startPerson] = true;

        cout << "BFS Traversal starting from " << startPerson << ": ";
        while (!q.empty()) {
            string curr = q.front();
            q.pop();
            cout << curr << " ";

            for (string neighbor : adjList[curr]) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    q.push(neighbor);
                }
            }
        }
        cout << endl;
    }

    void dfs(string startPerson) {
        map<string, bool> visited;
        cout << "DFS Traversal starting from " << startPerson << ": ";
        dfsHelper(startPerson, visited);
        cout << endl;
    }
};

int main() {
    SocialNetwork net;

    net.addPerson("Ajay");
    net.addPerson("Rahul");
    net.addPerson("Amit");
    net.addPerson("Priya");
    net.addPerson("Sneha");

    net.addFriendship("Ajay", "Rahul");
    net.addFriendship("Ajay", "Amit");
    net.addFriendship("Rahul", "Priya");
    net.addFriendship("Amit", "Sneha");

    net.displayGraph();

    net.bfs("Ajay");
    net.dfs("Ajay");

    return 0;
}
