#include <iostream>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int priority;
};

struct Node {
    Patient data;
    Node* next;
    
    Node(int id, string name, int priority) {
        data.id = id;
        data.name = name;
        data.priority = priority;
        next = nullptr;
    }
};

class HospitalQueue {
private:
    Node* front;
    Node* rear;

public:
    HospitalQueue() {
        front = nullptr;
        rear = nullptr;
    }

    void enqueue(int id, string name, int priority) {
        Node* newNode = new Node(id, name, priority);
        if (rear == nullptr) {
            front = rear = newNode;
            cout << "Patient " << name << " (ID: " << id << ") registered successfully." << endl;
            return;
        }
        rear->next = newNode;
        rear = newNode;
        cout << "Patient " << name << " (ID: " << id << ") registered successfully." << endl;
    }

    void dequeue() {
        if (front == nullptr) {
            cout << "No patients in the emergency queue." << endl;
            return;
        }
        Node* temp = front;
        cout << "Attending Patient: " << temp->data.name 
             << " (ID: " << temp->data.id 
             << ", Priority: " << temp->data.priority << ")" << endl;
        
        front = front->next;
        if (front == nullptr) {
            rear = nullptr;
        }
        delete temp;
    }

    void display() {
        if (front == nullptr) {
            cout << "Emergency Queue is empty." << endl;
            return;
        }
        cout << "\n--- Emergency Department Patient Queue ---" << endl;
        Node* temp = front;
        while (temp != nullptr) {
            cout << "ID: " << temp->data.id 
                 << " | Name: " << temp->data.name 
                 << " | Priority: " << temp->data.priority << endl;
            temp = temp->next;
        }
        cout << "------------------------------------------\n" << endl;
    }

    ~HospitalQueue() {
        while (front != nullptr) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
    }
};

int main() {
    HospitalQueue emergencyQueue;

    emergencyQueue.enqueue(101, "Rahul Sharma", 1);
    emergencyQueue.enqueue(102, "Ananya Roy", 3);
    emergencyQueue.enqueue(103, "Amit Patel", 2);

    emergencyQueue.display();

    emergencyQueue.dequeue();
    emergencyQueue.display();

    emergencyQueue.dequeue();
    emergencyQueue.dequeue();
    emergencyQueue.dequeue();

    return 0;
}
