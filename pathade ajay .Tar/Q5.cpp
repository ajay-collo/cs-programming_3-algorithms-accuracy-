#include <iostream>
#include <string>

using namespace std;

struct Employee {
    int id;
    string name;
    double salary;
};

struct Node {
    Employee data;
    Node* next;
    
    Node(int id, string name, double salary) {
        data.id = id;
        data.name = name;
        data.salary = salary;
        next = nullptr;
    }
};

class EmployeeList {
private:
    Node* head;

public:
    EmployeeList() { head = nullptr; }

    void insertAtBeginning(int id, string name, double salary) {
        Node* newNode = new Node(id, name, salary);
        newNode->next = head;
        head = newNode;
        cout << "Inserted " << name << " at the beginning." << endl;
    }

    void insertAtEnd(int id, string name, double salary) {
        Node* newNode = new Node(id, name, salary);
        if (head == nullptr) {
            head = newNode;
            cout << "Inserted " << name << " as first employee." << endl;
            return;
        }
        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
        cout << "Inserted " << name << " at the end." << endl;
    }

    void deleteEmployee(int id) {
        if (head == nullptr) {
            cout << "List is empty." << endl;
            return;
        }
        if (head->data.id == id) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << "Deleted employee with ID: " << id << endl;
            return;
        }
        Node* curr = head;
        while (curr->next != nullptr && curr->next->data.id != id) {
            curr = curr->next;
        }
        if (curr->next == nullptr) {
            cout << "Employee with ID " << id << " not found." << endl;
        } else {
            Node* temp = curr->next;
            curr->next = curr->next->next;
            delete temp;
            cout << "Deleted employee with ID: " << id << endl;
        }
    }

    void searchEmployee(int id) {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->data.id == id) {
                cout << "Found -> ID: " << temp->data.id << ", Name: " << temp->data.name << ", Salary: " << temp->data.salary << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "Employee with ID " << id << " not found." << endl;
    }

    void display() {
        if (head == nullptr) {
            cout << "Employee database is empty." << endl;
            return;
        }
        cout << "\n--- Employee Records List ---" << endl;
        Node* temp = head;
        while (temp != nullptr) {
            cout << "ID: " << temp->data.id << " | Name: " << temp->data.name << " | Salary: $" << temp->data.salary << endl;
            temp = temp->next;
        }
        cout << "-----------------------------\n" << endl;
    }
};

int main() {
    EmployeeList list;

    list.insertAtBeginning(101, "Ajay", 75000);
    list.insertAtEnd(102, "Rahul", 60000);
    list.insertAtEnd(103, "Amit", 65000);

    list.display();

    list.searchEmployee(102);
    list.deleteEmployee(101);

    list.display();

    return 0;
}
