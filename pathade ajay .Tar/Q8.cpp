#include <iostream>
#include <vector>
#include <list>
#include <map>

using namespace std;

class CoursePrerequisiteGraph {
private:
    map<string, list<string>> adjList;

public:
    void addCourse(string course) {
        if (adjList.find(course) == adjList.end()) {
            adjList[course] = list<string>();
        }
    }

    void addPrerequisite(string course, string prereq) {
        adjList[course].push_back(prereq);
    }

    void displayGraph() {
        cout << "\n--- Course Prerequisite Graph ---" << endl;
        for (auto pair : adjList) {
            cout << pair.first << " requires -> ";
            for (string p : pair.second) {
                cout << p << ", ";
            }
            cout << endl;
        }
        cout << "---------------------------------\n" << endl;
    }

    void displayPrerequisites(string course) {
        if (adjList.find(course) == adjList.end()) {
            cout << "Course not found." << endl;
            return;
        }
        cout << "Direct prerequisites for " << course << ": ";
        for (string p : adjList[course]) {
            cout << p << " ";
        }
        cout << endl;
    }
};

int main() {
    CoursePrerequisiteGraph uniGraph;

    uniGraph.addCourse("Data Structures");
    uniGraph.addCourse("Algorithms");
    uniGraph.addCourse("Advanced AI");

    uniGraph.addPrerequisite("Algorithms", "Data Structures");
    uniGraph.addPrerequisite("Advanced AI", "Algorithms");

    uniGraph.displayGraph();

    uniGraph.displayPrerequisites("Algorithms");

    return 0;
}
